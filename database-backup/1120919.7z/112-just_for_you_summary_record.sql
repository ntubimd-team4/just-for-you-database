-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 140.131.114.242    Database: 112-just_for_you
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `summary_record`
--

DROP TABLE IF EXISTS `summary_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `summary_record` (
  `s_id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `user_id` varchar(45) NOT NULL COMMENT '使用者Google帳號',
  `content` text NOT NULL COMMENT '內容',
  `summary` text COMMENT '內容摘要',
  `establish_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '對話建立時間(時間軸)',
  `create_id` varchar(45) NOT NULL COMMENT '新增者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增時間',
  `modify_id` varchar(45) DEFAULT NULL COMMENT '修改者',
  `modify_time` datetime DEFAULT NULL COMMENT '修改時間',
  PRIMARY KEY (`s_id`),
  UNIQUE KEY `s_id_UNIQUE` (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='摘要紀錄';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summary_record`
--

LOCK TABLES `summary_record` WRITE;
/*!40000 ALTER TABLE `summary_record` DISABLE KEYS */;
INSERT INTO `summary_record` VALUES (1,'10946012@ntub.edu.tw','資料庫同步、MSSQL、MySQL之間轉換好麻煩，索引、view表也好複雜，啥時才能結束這些可怕的同步地獄','我正在努力對資料庫進行同步，但MSSQL與MySQL之間的轉換非常麻煩，而索引和view表也很複雜，我希望能早點結束這個可怕的同步地獄。','2023-09-03 16:40:15','10946012@ntub.edu.tw','2023-09-03 16:40:15',NULL,NULL),(2,'10946012@ntub.edu.tw','今天一早起床就看到工作訊息還有未接來電，心情糟了一天','今天一早起床，就看到工作訊息和未接來電，讓我的心情糟糕了一整天。','2023-09-03 16:40:42','10946012@ntub.edu.tw','2023-09-03 16:40:42',NULL,NULL),(3,'10946011@ntub.edu.tw','記憶力逐年衰退感到很挫折','我感到很挫折，因為我的記憶力正在逐年衰退。','2023-09-03 16:45:08','10946012@ntub.edu.tw','2023-09-03 16:45:08',NULL,NULL),(4,'10946011@ntub.edu.tw','最近心情很糟，遇到甚麼事都很不順利','最近我的心情很糟，不管遇到什麼事情都不順利，感到很沮喪和無助。','2023-09-17 15:39:22','10946011@ntub.edu.tw','2023-09-17 15:39:22',NULL,NULL),(5,'10946011@ntub.edu.tw','今天天氣很好，我相信這星期會過得很順利!','：我很高興今天的天氣，並且相信本星期會過得很順利。','2023-09-19 11:23:26','10946011@ntub.edu.tw','2023-09-19 11:23:26',NULL,NULL),(6,'10946011@ntub.edu.tw','','I had a great day at the beach with my family.I spent a wonderful day at the beach with my family, enjoying the sun and the waves.','2023-09-19 11:26:49','10946011@ntub.edu.tw','2023-09-19 11:26:49',NULL,NULL),(7,'10946011@ntub.edu.tw','sdf','我正在研究sdf。我正在研究sdf，以了解更多有關它的知識。','2023-09-19 11:28:55','10946011@ntub.edu.tw','2023-09-19 11:28:55',NULL,NULL),(8,'10946011@ntub.edu.tw','今天很開心','今天我很開心，因為我感到快樂。','2023-09-19 11:37:39','10946011@ntub.edu.tw','2023-09-19 11:37:39',NULL,NULL),(9,'10946011@ntub.edu.tw','dfgfdgdfg','我看過這句話，它給了我一個啟發，讓我明白到應該把握每個機會，因為它們可能會帶來獨特的機會和收穫。','2023-09-19 11:59:02','10946011@ntub.edu.tw','2023-09-19 11:59:02',NULL,NULL),(10,'10946011@ntub.edu.tw','dfgdfgfdg','我正在研究這句話。我正在試圖了解這句話的意思。','2023-09-19 12:00:39','10946011@ntub.edu.tw','2023-09-19 12:00:39',NULL,NULL),(11,'10946011@ntub.edu.tw','ghjghj','我正在努力學習新的技能，以提升自己的競爭力。我正在努力學習新的技能，以便能夠在競爭中脫穎而出。','2023-09-19 12:01:21','10946011@ntub.edu.tw','2023-09-19 12:01:21',NULL,NULL),(12,'10946011@ntub.edu.tw','teset','我正在尋找一個有趣的工作。我正在尋求一份新的工作，能給我更多挑戰和樂趣。','2023-09-19 12:14:50','10946011@ntub.edu.tw','2023-09-19 12:14:50',NULL,NULL),(13,'10946011@ntub.edu.tw','asdasd','我對這句話做了簡單的摘要：我試圖簡單地概括這句話。','2023-09-19 12:22:09','10946011@ntub.edu.tw','2023-09-19 12:22:09',NULL,NULL),(14,'10946011@ntub.edu.tw','sdfsdf','我想要瞭解更多關於這個主題。我想了解更多關於這個主題。','2023-09-19 12:25:18','10946011@ntub.edu.tw','2023-09-19 12:25:18',NULL,NULL),(15,'10946011@ntub.edu.tw','sdfsdf','我正在思考一個問題。我正在考慮一個問題。','2023-09-19 12:27:31','10946011@ntub.edu.tw','2023-09-19 12:27:31',NULL,NULL),(16,'10946011@ntub.edu.tw','sdjklfjlsd\n','我聽到了一些奇怪的聲音。','2023-09-19 12:37:45','10946011@ntub.edu.tw','2023-09-19 12:37:45',NULL,NULL),(17,'10946011@ntub.edu.tw','rtyrty','我試著去理解這句話，但是它似乎沒有任何意義。','2023-09-19 12:38:33','10946011@ntub.edu.tw','2023-09-19 12:38:33',NULL,NULL),(18,'10946011@ntub.edu.tw','test','I went to the store to buy some groceries.I went to the store to get groceries.','2023-09-19 12:47:58','10946011@ntub.edu.tw','2023-09-19 12:47:58',NULL,NULL);
/*!40000 ALTER TABLE `summary_record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-19 17:26:05
